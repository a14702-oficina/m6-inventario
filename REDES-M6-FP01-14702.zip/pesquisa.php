<?php
include "config.php";
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Pesquisa Geral - Inventário TI</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
  --cor-primaria: #6a11cb;
  --cor-secundaria: #2575fc;
  --cor-fundo: #f0f4ff;
}

body {
  background: var(--cor-fundo);
  font-family: 'Segoe UI', sans-serif;
}

.navbar {
  background: linear-gradient(90deg, var(--cor-primaria), var(--cor-secundaria));
}

.search-box {
  position: relative;
}

#results {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 10px 25px rgba(0,0,0,.12);
  overflow: hidden;
  display: none;
  z-index: 1000;
}

.result-item {
  padding: 12px 16px;
  border-bottom: 1px solid #eee;
  cursor: pointer;
  transition: background .2s;
}

.result-item:last-child {
  border-bottom: none;
}

.result-item:hover,
.result-item.active {
  background: #f0f4ff;
}

.result-title {
  font-weight: 600;
}

.result-meta {
  font-size: 13px;
  color: #666;
}

.status {
  font-size: 14px;
  color: #666;
  margin-top: 10px;
}
</style>
</head>

<body>

<nav class="navbar navbar-dark mb-4">
  <div class="container d-flex justify-content-between align-items-center">
    <span class="navbar-brand">
      <i class="bi bi-search me-2"></i> Pesquisa Geral
    </span>
    <a href="index.php" class="btn btn-outline-light btn-sm">
      <i class="bi bi-arrow-left"></i> Voltar
    </a>
  </div>
</nav>

<div class="container">

<div class="card p-4 shadow-sm mb-4">
  <h4 class="fw-bold mb-2">
    <i class="bi bi-pc-display me-2"></i> Pesquisa de Computadores
  </h4>

  <p class="text-muted mb-3">
    Pesquisa por <b>nome</b>, <b>sistema operativo</b>, <b>processador</b> ou <b>software</b>
  </p>

  <div class="search-box">
    <input id="q" type="text" class="form-control form-control-lg"
           placeholder="Começa a escrever..." autocomplete="off">

    <div id="results"></div>
  </div>

  <div id="status" class="status">
    Escreve pelo menos 2 caracteres…
  </div>
</div>

</div>

<script>
const input = document.getElementById('q');
const resultsBox = document.getElementById('results');
const statusEl = document.getElementById('status');

let debounceTimer = null;
let lastQuery = '';
let activeIndex = -1;

function escapeHtml(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function hideResults() {
  resultsBox.style.display = 'none';
  resultsBox.innerHTML = '';
  activeIndex = -1;
}

function showResults(items) {
  if (!items || items.length === 0) {
    resultsBox.innerHTML =
      `<div class="result-item text-muted">Sem resultados encontrados.</div>`;
    resultsBox.style.display = 'block';
    return;
  }

  resultsBox.innerHTML = items.map((it, idx) => `
    <div class="result-item" data-idx="${idx}" data-id="${it.id_computador}">
      <div class="result-title">${escapeHtml(it.nome_computador)}</div>
      <div class="result-meta">
        Sala: ${escapeHtml(it.nome_sala)} ·
        SO: ${escapeHtml(it.sistema_operativo || '—')} ·
        RAM: ${escapeHtml(it.ram || '—')}
      </div>
    </div>
  `).join('');

  resultsBox.style.display = 'block';

  resultsBox.querySelectorAll('.result-item[data-id]').forEach(el => {
    el.addEventListener('click', () => {
      window.location.href = `detalhe.php?id=${el.dataset.id}`;
    });
  });
}

async function fetchResults(q) {
  if (q.trim().length < 2) {
    statusEl.textContent = 'Escreve pelo menos 2 caracteres…';
    hideResults();
    return;
  }

  statusEl.textContent = 'A procurar…';

  try {
    const res = await fetch(`api_pesquisa.php?q=${encodeURIComponent(q)}`);
    const data = await res.json();

    if (q !== lastQuery) return;

    statusEl.textContent = data.length
      ? `${data.length} resultado(s) encontrados`
      : 'Sem resultados encontrados';

    showResults(data);
  } catch {
    statusEl.textContent = 'Erro ao pesquisar.';
    hideResults();
  }
}

input.addEventListener('input', () => {
  lastQuery = input.value;
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => fetchResults(input.value), 300);
});

document.addEventListener('click', e => {
  if (!resultsBox.contains(e.target) && e.target !== input) hideResults();
});

input.focus();
</script>

</body>
</html>
