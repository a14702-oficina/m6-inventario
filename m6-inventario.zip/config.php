<?php
$host = "sql300.infinityfree.com";
$dbname = "if0_40156181_inventario";
$user = "if0_40156181";
$pass = "3lxGnvbpQ1rU3"; // no XAMPP normalmente é vazio

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na ligação à BD: " . $e->getMessage());
}
?>