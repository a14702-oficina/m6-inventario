<?php
include "config.php";

// buscar salas
$salas = $pdo->query("SELECT * FROM salas")->fetchAll();

// contar computadores por sala
$salas_com_totais = $pdo->query("
  SELECT s.id_sala, s.nome_sala, s.localizacao,
         COUNT(c.id_computador) AS total_computadores
  FROM salas s
  LEFT JOIN computadores c ON c.id_sala = s.id_sala
  GROUP BY s.id_sala
")->fetchAll();

// definir sala selecionada (por defeito: primeira)
$id_sala = isset($_GET["sala"]) ? (int)$_GET["sala"] : ($salas[0]["id_sala"] ?? 0);

// buscar computadores da sala
$stmt = $pdo->prepare("SELECT * FROM computadores WHERE id_sala = ?");
$stmt->execute([$id_sala]);
$computadores = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Inventário de Computadores</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-4">

  <!-- Título -->
  <div class="mb-4">
    <h1 class="fw-bold">
      <i class="bi bi-pc-display"></i> Inventário de Computadores
    </h1>
    <p class="text-muted">Visão geral dos computadores por sala</p>
  </div>

  <!-- Cards das salas -->
  <div class="row g-3 mb-4">
    <?php foreach ($salas_com_totais as $s): ?>
      <div class="col-md-4 col-lg-3">
        <a href="?sala=<?= $s["id_sala"] ?>" class="text-decoration-none">
          <div class="card shadow-sm h-100 <?= ($s["id_sala"] == $id_sala) ? 'border-primary' : '' ?>">
            <div class="card-body text-center">
              <i class="bi bi-door-open fs-2 text-primary"></i>
              <h5 class="mt-2 mb-0 text-dark"><?= $s["nome_sala"] ?></h5>
              <small class="text-muted"><?= $s["localizacao"] ?></small>

              <div class="mt-3">
                <span class="badge bg-primary fs-6">
                  <?= $s["total_computadores"] ?> <i class="bi bi-pc"></i>
                </span>
              </div>
            </div>
          </div>
        </a>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Filtro + tabela -->
  <div class="card shadow-sm">
    <div class="card-body">

      <!-- Filtro -->
      <form method="get" class="row g-3 align-items-end mb-3">
        <div class="col-md-6">
          <label for="sala" class="form-label">
            <i class="bi bi-filter"></i> Filtrar por sala
          </label>
          <select name="sala" id="sala" class="form-select">
            <?php foreach ($salas as $s): ?>
              <option value="<?= $s["id_sala"] ?>" <?= ($s["id_sala"] == $id_sala) ? "selected" : "" ?>>
                <?= $s["nome_sala"] ?> (<?= $s["localizacao"] ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3">
          <button type="submit" class="btn btn-primary w-100">
            <i class="bi bi-search"></i> Ver computadores
          </button>
        </div>
      </form>

      <!-- Tabela -->
      <?php if (count($computadores) == 0): ?>
        <div class="text-center text-muted py-4">
          <i class="bi bi-info-circle fs-3"></i>
          <p class="mt-2 mb-0">Não existem computadores nesta sala.</p>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr>
                <th><i class="bi bi-pc"></i> Nome</th>
                <th><i class="bi bi-windows"></i> Sistema Operativo</th>
                <th><i class="bi bi-memory"></i> RAM</th>
                <th class="text-center"><i class="bi bi-gear"></i> Ações</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($computadores as $pc): ?>
                <tr>
                  <td class="fw-semibold"><?= $pc["nome_computador"] ?></td>
                  <td><?= $pc["sistema_operativo"] ?></td>
                  <td><?= $pc["ram"] ?></td>
                  <td class="text-center">
                    <a href="detalhe.php?id=<?= $pc["id_computador"] ?>" class="btn btn-sm btn-outline-primary">
                      <i class="bi bi-eye"></i> Detalhe
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

    </div>
  </div>

</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
