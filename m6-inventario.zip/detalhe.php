<?php
include "config.php";

$id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;

// buscar dados do computador
$stmt = $pdo->prepare("SELECT * FROM computadores WHERE id_computador = ?");
$stmt->execute([$id]);
$pc = $stmt->fetch();

if (!$pc) {
  die("Computador não encontrado.");
}

// buscar software instalado
$stmt2 = $pdo->prepare("
  SELECT s.nome_software, s.versao
  FROM software s
  INNER JOIN computador_software cs ON s.id_software = cs.id_software
  WHERE cs.id_computador = ?
");
$stmt2->execute([$id]);
$softwares = $stmt2->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title><?= $pc["nome_computador"] ?></title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-4">

  <!-- Voltar -->
  <a href="index.php" class="btn btn-outline-secondary mb-3">
    <i class="bi bi-arrow-left"></i> Voltar
  </a>

  <!-- Cabeçalho -->
  <div class="mb-4">
    <h1 class="fw-bold">
      <i class="bi bi-pc-display"></i> <?= $pc["nome_computador"] ?>
    </h1>
    <p class="text-muted">Detalhes do computador</p>
  </div>

  <div class="row g-4">

    <!-- Características -->
    <div class="col-md-6">
      <div class="card shadow-sm h-100">
        <div class="card-header bg-white">
          <h5 class="mb-0">
            <i class="bi bi-info-circle"></i> Características
          </h5>
        </div>
        <div class="card-body">
          <ul class="list-group list-group-flush">
            <li class="list-group-item">
              <i class="bi bi-cpu"></i>
              <strong> Processador:</strong> <?= $pc["processador"] ?>
            </li>
            <li class="list-group-item">
              <i class="bi bi-memory"></i>
              <strong> RAM:</strong> <?= $pc["ram"] ?>
            </li>
            <li class="list-group-item">
              <i class="bi bi-hdd"></i>
              <strong> Armazenamento:</strong> <?= $pc["armazenamento"] ?>
            </li>
            <li class="list-group-item">
              <i class="bi bi-windows"></i>
              <strong> Sistema Operativo:</strong> <?= $pc["sistema_operativo"] ?>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Software -->
    <div class="col-md-6">
      <div class="card shadow-sm h-100">
        <div class="card-header bg-white">
          <h5 class="mb-0">
            <i class="bi bi-boxes"></i> Software Instalado
          </h5>
        </div>
        <div class="card-body">
          <?php if (count($softwares) == 0): ?>
            <div class="text-center text-muted py-4">
              <i class="bi bi-info-circle fs-3"></i>
              <p class="mt-2 mb-0">Nenhum software associado.</p>
            </div>
          <?php else: ?>
            <ul class="list-group">
              <?php foreach ($softwares as $sw): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    <i class="bi bi-app"></i>
                    <?= $sw["nome_software"] ?>
                  </span>
                  <span class="badge bg-secondary">
                    <?= $sw["versao"] ?>
                  </span>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      </div>
    </div>

  </div>

</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
