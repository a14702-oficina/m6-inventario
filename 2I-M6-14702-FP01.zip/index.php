<?php
include "config.php";

// Buscar salas + total de computadores
$sql_salas = "
    SELECT s.id_sala, s.nome_sala, s.localizacao,
           COUNT(c.id_computador) AS total
    FROM salas s
    LEFT JOIN computadores c ON c.id_sala = s.id_sala
    GROUP BY s.id_sala
    ORDER BY s.nome_sala
";
$salas = $pdo->query($sql_salas)->fetchAll(PDO::FETCH_ASSOC);

// Sala selecionada
$id_sala = isset($_GET['sala']) ? (int)$_GET['sala'] : ($salas[0]['id_sala'] ?? 0);

// Pesquisa
$pesquisa = isset($_GET['pesquisa']) ? trim($_GET['pesquisa']) : '';
$termo = "%$pesquisa%";

// Buscar computadores
if ($pesquisa) {
    $sql = "
        SELECT DISTINCT c.*, s.nome_sala
        FROM computadores c
        JOIN salas s ON c.id_sala = s.id_sala
        LEFT JOIN computador_software cs ON cs.id_computador = c.id_computador
        LEFT JOIN software sw ON sw.id_software = cs.id_software
        WHERE c.id_sala = ?
        AND (
            c.nome_computador LIKE ?
            OR c.processador LIKE ?
            OR c.sistema_operativo LIKE ?
            OR sw.nome_software LIKE ?
        )
        ORDER BY c.nome_computador
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id_sala, $termo, $termo, $termo, $termo]);
} else {
    $sql = "
        SELECT c.*, s.nome_sala
        FROM computadores c
        JOIN salas s ON c.id_sala = s.id_sala
        WHERE c.id_sala = ?
        ORDER BY c.nome_computador
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id_sala]);
}

$computadores = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Inventário TI</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
  --cor-primaria: #6a11cb;
  --cor-secundaria: #2575fc;
  --cor-sucesso: #4caf50;
  --cor-aviso: #f9a825;
  --cor-fundo: #f0f4ff;
}

body { 
    background: var(--cor-fundo);
    font-family: 'Segoe UI', sans-serif;
}
.navbar { background: linear-gradient(90deg, var(--cor-primaria), var(--cor-secundaria)); }
.navbar-brand { font-weight: 600; }

.card, .card-sala { border-radius:14px; transition: all 0.3s; box-shadow: 0 5px 15px rgba(0,0,0,0.08);}
.card:hover, .card-sala:hover { transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0,0,0,0.15); }

.card-sala { padding:20px; background:white; cursor:pointer; }
.card-sala.active { border: 3px solid var(--cor-primaria); background: linear-gradient(135deg, rgba(106,17,203,.1), rgba(37,117,252,.1)); }

.badge { font-size:0.85rem; padding:0.5em 0.8em; }
.badge-soft { background: rgba(106,17,203,.1); color: var(--cor-primaria); }

.table-custom th { background: var(--cor-primaria); color:white; }
.table-custom td { vertical-align: middle; }

.btn-primary, .btn-outline-primary { border-radius:10px; }

.input-pesquisa, .select-sala { border-radius:10px; padding:10px; }

</style>
</head>
<body>

<nav class="navbar navbar-dark mb-4">
<div class="container">
    <span class="navbar-brand"><i class="bi bi-pc-display me-2"></i> Inventário TI</span>
    <span class="text-white"><?= date('d/m/Y') ?></span>
</div>
</nav>

<div class="container">

<h2 class="fw-bold mb-4">Salas</h2>
<div class="row mb-4">
<?php foreach ($salas as $s): ?>
<div class="col-md-3 mb-3">
    <a href="?sala=<?= $s['id_sala'] ?>" class="text-decoration-none">
        <div class="card-sala <?= $s['id_sala']==$id_sala?'active':'' ?>">
            <h5 class="fw-bold"><?= htmlspecialchars($s['nome_sala']) ?></h5>
            <small><?= htmlspecialchars($s['localizacao']) ?></small><br>
            <span class="badge bg-success mt-2">
                <i class="bi bi-pc"></i> <?= $s['total'] ?> computadores
            </span>
        </div>
    </a>
</div>
<?php endforeach; ?>
</div>

<form class="row g-3 mb-4">
<input type="hidden" name="sala" value="<?= $id_sala ?>">
<div class="col-md-9">
<input type="text" name="pesquisa" class="form-control input-pesquisa"
       placeholder="Pesquisar computador ou software" value="<?= htmlspecialchars($pesquisa) ?>">
</div>
<div class="col-md-3">
<button class="btn btn-primary w-100"><i class="bi bi-search"></i> Pesquisar</button>
</div>
</form>

<div class="card p-4">
<h4 class="fw-bold mb-3"><i class="bi bi-pc-display me-2"></i> Computadores</h4>
<?php if (!$computadores): ?>
<p class="text-muted">Nenhum computador encontrado.</p>
<?php else: ?>
<div class="table-responsive">
<table class="table table-hover table-custom mb-0">
<thead>
<tr>
<th>Nome</th>
<th>Processador</th>
<th>RAM</th>
<th>Sistema</th>
<th>Ações</th>
</tr>
</thead>
<tbody>
<?php foreach ($computadores as $pc): ?>
<tr>
<td><?= htmlspecialchars($pc['nome_computador']) ?></td>
<td><?= htmlspecialchars($pc['processador']) ?></td>
<td><?= htmlspecialchars($pc['ram']) ?></td>
<td><?= htmlspecialchars($pc['sistema_operativo']) ?></td>
<td>
<a href="detalhe.php?id=<?= $pc['id_computador'] ?>" class="btn btn-outline-primary btn-sm">
<i class="bi bi-eye"></i> Detalhes</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php endif; ?>
</div>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
