<?php
include "config.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { header("Location: index.php"); exit; }

$sql = "
    SELECT c.*, s.nome_sala, s.localizacao
    FROM computadores c
    LEFT JOIN salas s ON s.id_sala = c.id_sala
    WHERE c.id_computador = ?
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$computador = $stmt->fetch();
if (!$computador) { header("Location: index.php"); exit; }

$sql_sw = "
    SELECT s.nome_software, s.versao
    FROM software s
    JOIN computador_software cs ON cs.id_software = s.id_software
    WHERE cs.id_computador = ?
";
$stmt = $pdo->prepare($sql_sw);
$stmt->execute([$id]);
$softwares = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($computador['nome_computador']) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
  --cor-primaria: #6a11cb;
  --cor-secundaria: #2575fc;
  --cor-sucesso: #4caf50;
  --cor-fundo: #f0f4ff;
}
body { background: var(--cor-fundo); font-family:'Segoe UI',sans-serif; }
.navbar { background: linear-gradient(90deg, var(--cor-primaria), var(--cor-secundaria)); }
.card { border-radius:14px; box-shadow:0 5px 15px rgba(0,0,0,0.08); margin-bottom:20px; }
.badge { font-size:0.85rem; padding:0.5em 0.8em; }
</style>
</head>
<body>

<nav class="navbar navbar-dark mb-4">
<div class="container">
<a href="index.php" class="navbar-brand"><i class="bi bi-arrow-left"></i> Voltar</a>
</div>
</nav>

<div class="container">

<h2 class="fw-bold mb-3"><?= htmlspecialchars($computador['nome_computador']) ?></h2>
<p>
<span class="badge bg-secondary"><?= htmlspecialchars($computador['nome_sala']) ?></span>
<span class="badge bg-info"><?= htmlspecialchars($computador['localizacao']) ?></span>
</p>

<div class="row">
<div class="col-md-8">
<div class="card p-4">
<h4 class="fw-bold"><i class="bi bi-cpu me-2"></i>Especificações</h4>
<p><strong>Processador:</strong> <?= htmlspecialchars($computador['processador']) ?></p>
<p><strong>RAM:</strong> <?= htmlspecialchars($computador['ram']) ?></p>
<p><strong>Armazenamento:</strong> <?= htmlspecialchars($computador['armazenamento']) ?></p>
<p><strong>Sistema Operativo:</strong> <?= htmlspecialchars($computador['sistema_operativo']) ?></p>
<p><strong>Placa Gráfica:</strong> <?= htmlspecialchars($computador['placa_grafica']) ?></p>
</div>
</div>

<div class="col-md-4">
<div class="card p-4">
<h4 class="fw-bold"><i class="bi bi-boxes me-2"></i>Software <span class="badge bg-primary"><?= count($softwares) ?></span></h4>
<?php if (!$softwares): ?>
<p class="text-muted">Nenhum software instalado.</p>
<?php else: ?>
<?php foreach ($softwares as $sw): ?>
<div class="border rounded p-2 mb-2">
<strong><?= htmlspecialchars($sw['nome_software']) ?></strong><br>
<small>Versão <?= htmlspecialchars($sw['versao']) ?></small>
</div>
<?php endforeach; ?>
<?php endif; ?>
</div>
</div>
</div>

<footer class="text-center text-muted py-3">
Inventário TI • Computador ID <?= $id ?>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
